from simple_pid import PID
import matplotlib.pyplot as plt
import numpy as np
import math
import control
import time


table = {}
values = []
torques = []
m = 300 #kg double check later 
gain = 1 #change later to something appropriate
pwms = [80, 85, 90, 95, 100, 105, 115, 120, 125]
for pwm in pwms:
    IMU_time = []
    accel_x = []
    with open(f'/home/leen/Desktop/pothole_detection_avoidance_agv/car_data/accel_{pwm}', 'r') as f:
        # Read each line
        for line in f:
            # Split the line into a list of strings
            values = line.split()
            IMU_time.append(float(values[1]))
            accel_x.append(float(values[2])*9.81)
    accel_x = np.array(accel_x)
    IMU_time = np.array(IMU_time)
    bias = np.average(accel_x[0:40])
    accel_x = accel_x - bias
    for i in range(len(accel_x)):
        if accel_x[i] > 0.05:
            accel_x = accel_x[i:]
            IMU_time = IMU_time[i:]
            break
    for i in range(len(accel_x)):
        if accel_x[i] < -0.15:
            accel_x = accel_x[:i]
            IMU_time = IMU_time[:i]
            break
    # calculate the velocity using the trapezoidal rule
    vel = np.cumsum((accel_x[1:] + accel_x[:-1]) / 2 * (IMU_time[1:] - IMU_time[:-1]))*9.81
    print(pwm)
    plt.figure(1)
    plt.plot(IMU_time[1:], vel)
    
    plt.figure(2)
    plt.plot(IMU_time[1:],accel_x[0:-1])
    plt.show()
    # add initial velocity to the velocity array
    vel = np.insert(vel, 0, 0)
    accel_x = np.insert(accel_x, 0, 0)

    velocities = list(vel)
    torques = list(accel_x*9.81*gain + 0.01*9.81*m)
    # Create a nested dictionary for the table
    table[pwm] = {}
    for i in range(len(velocities)):
        # Add the torque value to the table
        table[pwm][velocities[i]] = torques[i]
    
# print(table)
    
## Controller design

k_p = 3
k_i= 0.25
k_d = 0
tau = 0.5
num_v = [k_p, k_i]
den_v = [tau, 1, k_p, k_i]

# V_x from imu
# V_des from pure pursuit
error = []
for V_x in vel:
    error.append(V_des - V_x)
error_i = np.cumsum((error[1:] + error[:-1]) / 2 * (IMU_time[1:] - IMU_time[:-1]))*9.81
ax_des = k_p *(error[-1]) + k_i*(error_i)

Torque = ax_des*9.81*gain + 0.01*9.81*m
velocity =  some_Imu_measurement


#But this assumes that the velocity needs to be dead on, so need to fix that
for pwm, v in table.items():
        if V_x in v and abs(v[V_x[i]]-Torque)<0.5:
            print(pwm)
        
        else:
            print("no no no")
# print(type(v_out))

# print(len(y)) (776)

# # Plot the input and output signals
# import matplotlib.pyplot as plt
# plt.plot(t,v_out, label='Input')
# # plt.plot(t, y, label='Output')
# plt.legend()
# plt.show()
